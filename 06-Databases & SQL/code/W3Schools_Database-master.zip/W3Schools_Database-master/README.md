# W3Schools_Database
Database used on w3schools for SQL tutorials

I'm not associated with W3Schools, this is their website:

https://www.w3schools.com

W3Schools database used in SQL tutorial here:

https://www.w3schools.com/sql/default.asp

Database tables and data on the right hand side if you run this example:

https://www.w3schools.com/sql/trysql.asp?filename=trysql_select_all

I couldn't find a location on w3schools to download the database, so I googled it. I found that user AndrejPHP created a query to create the database in SQL, however his code appeared to be outdated when I tried to run it.
https://github.com/AndrejPHP/w3schools-database

I updated his code for it to be available to users to run as of 9/19/2019.
Execute w3schools_Creation.sql first, to create the overall database.
Execute w3schools_DataImport.sql second, to import the data.

I tried to combine both querys into one file, to make it easier on the user, however I got an error when trying to do so. If anyone can figure out how to do so, let me know.
